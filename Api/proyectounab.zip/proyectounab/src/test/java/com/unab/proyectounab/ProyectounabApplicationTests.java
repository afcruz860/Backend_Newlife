package com.unab.proyectounab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectounabApplicationTests {

	@Test
	void contextLoads() {
	}

}
